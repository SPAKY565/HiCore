<?php
$smtp = ""; //smtp server adress
$mail_server = ""; //mail adress
$mail_server_password = ""; //mail password
$mail_type = 'ssl'; // choose ssl or tls
$smtp_port = 465; //smtp port
$url_register = "DOMAIN/tools/activate.php";
$url_reset = "DOMAIN/tools/reset.php"; //enter url to your activate account file. Example: https://example.com/database/activate.php
?>
