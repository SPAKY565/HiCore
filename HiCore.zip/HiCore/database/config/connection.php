<?php
$servername = "sql4.5v.pl";
$port = 3306;
$username = "ss123trs_fivescriptl";
$password = "76600282Rr";
$dbname = "ss123trs_fivescriptl";
?>