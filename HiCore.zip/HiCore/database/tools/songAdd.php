<?php
header('Location: songs/upload.php');
exit;
?>
