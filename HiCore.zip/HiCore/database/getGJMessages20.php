<?php
include "incl/messages/getGJMessages.php";
?>