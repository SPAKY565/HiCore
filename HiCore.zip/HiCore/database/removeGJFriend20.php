<?php
include "incl/relationships/removeGJFriend.php";
?>