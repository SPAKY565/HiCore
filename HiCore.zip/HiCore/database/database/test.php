<?php
$sakujes = ["test","test2","test3"];
$sakujes2 = implode('","',$sakujes);
echo $sakujes2;