<?php
include "incl/misc/getAccountURL.php";
?>