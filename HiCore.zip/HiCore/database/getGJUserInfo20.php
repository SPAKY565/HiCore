<?php
include "incl/profiles/getGJUserInfo.php";
?>